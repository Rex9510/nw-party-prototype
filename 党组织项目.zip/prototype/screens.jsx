/**
 * 南湾红帆党务智管家 - 小程序端原型
 * 13 screens high-fidelity prototype
 */

// ========== 导航上下文和路由系统 ==========
const NavigationContext = React.createContext();
const NavigationProvider = ({ children }) => {
  const [currentScreen, setCurrentScreen] = React.useState('login');
  const [navigationStack, setNavigationStack] = React.useState(['login']);

  const navigateTo = (screenName, params = {}) => {
    setCurrentScreen(screenName);
    setNavigationStack(prev => [...prev, { name: screenName, params }]);
  };

  const goBack = () => {
    setNavigationStack(prev => {
      if (prev.length <= 1) return prev;
      const newStack = prev.slice(0, -1);
      setCurrentScreen(newStack[newStack.length - 1].name);
      return newStack;
    });
  };

  const navigateWithReset = (screenName) => {
    setCurrentScreen(screenName);
    setNavigationStack([screenName]);
  };

  return (
    <NavigationContext.Provider value={{ currentScreen, navigationStack, navigateTo, goBack, navigateWithReset }}>
      {children}
    </NavigationContext.Provider>
  );
};

const useNavigation = () => React.useContext(NavigationContext);

// ========== 共享样式 ==========
const theme = {
  primary: '#E53935',
  primaryLight: '#FFEBEE',
  primaryDark: '#C62828',
  bg: '#F5F5F5',
  white: '#FFFFFF',
  text: '#1A1A1A',
  textSecondary: '#666666',
  textMuted: '#999999',
  border: '#E8E8E8',
  success: '#4CAF50',
  warning: '#FF9800',
  card: '#FFFFFF',
  cardShadow: '0 1px 4px rgba(0,0,0,0.08)',
  cardShadowLg: '0 4px 16px rgba(0,0,0,0.12)',
};

const iosFrameStyles = {
  wrapper: {
    display: 'inline-block',
    padding: 12,
    background: '#000',
    borderRadius: 60,
    boxShadow: '0 0 0 2px #1f2937, 0 20px 60px rgba(0,0,0,0.3)',
    position: 'relative',
  },
  screen: {
    position: 'relative',
    borderRadius: 48,
    overflow: 'hidden',
    background: theme.bg,
  },
  statusBar: {
    position: 'absolute',
    top: 0, left: 0, right: 0,
    height: 54,
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '0 32px 0 32px',
    fontSize: 16, fontWeight: 600,
    fontFamily: '-apple-system, "SF Pro Text", sans-serif',
    zIndex: 20, pointerEvents: 'none',
  },
  dynamicIsland: {
    position: 'absolute', top: 12, left: '50%', transform: 'translateX(-50%)',
    width: 124, height: 36, background: '#000', borderRadius: 999, zIndex: 30,
  },
  statusIcons: { display: 'flex', alignItems: 'center', gap: 6 },
  signalIcon: { display: 'flex', alignItems: 'flex-end', gap: 2, height: 12 },
  signalBar: { width: 3, background: 'currentColor', borderRadius: 1 },
  batteryIcon: {
    width: 26, height: 12, border: '1.5px solid currentColor', borderRadius: 3,
    padding: 1, position: 'relative', opacity: 0.8,
  },
  batteryCap: {
    position: 'absolute', top: 3, right: -3, width: 2, height: 6,
    background: 'currentColor', borderRadius: '0 1px 1px 0',
  },
  content: {
    position: 'absolute', top: 54, left: 0, right: 0, bottom: 34,
    overflow: 'auto',
  },
  homeIndicator: {
    position: 'absolute', bottom: 10, left: '50%', transform: 'translateX(-50%)',
    width: 140, height: 5, background: 'rgba(0,0,0,0.3)', borderRadius: 999, zIndex: 10,
  },
  homeIndicatorDark: { background: 'rgba(255,255,255,0.5)' },
};

function IosFrame({ children, width = 393, height = 852, time = '9:41', battery = 85, darkMode = false, showStatusBar = true, showDynamicIsland = true, showHomeIndicator = true }) {
  const textColor = darkMode ? '#fff' : '#000';
  return (
    <div style={iosFrameStyles.wrapper}>
      <div style={{ ...iosFrameStyles.screen, width, height, background: darkMode ? '#000' : theme.bg }}>
        {showStatusBar && (
          <div style={{ ...iosFrameStyles.statusBar, color: textColor }}>
            <span>{time}</span>
            <div style={iosFrameStyles.statusIcons}>
              <div style={iosFrameStyles.signalIcon}>
                <div style={{ ...iosFrameStyles.signalBar, height: 4 }} />
                <div style={{ ...iosFrameStyles.signalBar, height: 6 }} />
                <div style={{ ...iosFrameStyles.signalBar, height: 9 }} />
                <div style={{ ...iosFrameStyles.signalBar, height: 11 }} />
              </div>
              <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
                <path d="M8 11.5a1 1 0 100-2 1 1 0 000 2z" fill="currentColor" />
                <path d="M3 7.5a7 7 0 0110 0" stroke="currentColor" strokeWidth="1.3" fill="none" strokeLinecap="round" />
                <path d="M1 4.5a11 11 0 0114 0" stroke="currentColor" strokeWidth="1.3" fill="none" strokeLinecap="round" opacity="0.7" />
              </svg>
              <div style={iosFrameStyles.batteryIcon}>
                <div style={{ width: `${battery}%`, height: '100%', background: 'currentColor', borderRadius: 1, opacity: 0.9 }} />
                <div style={iosFrameStyles.batteryCap} />
              </div>
            </div>
          </div>
        )}
        {showDynamicIsland && <div style={iosFrameStyles.dynamicIsland} />}
        <div style={iosFrameStyles.content}>{children}</div>
        {showHomeIndicator && <div style={{ ...iosFrameStyles.homeIndicator, ...(darkMode ? iosFrameStyles.homeIndicatorDark : {}) }} />}
      </div>
    </div>
  );
}

// 微信风格导航栏
function WxNavBar({ title, back = false, onBack }) {
  return (
    <div style={{
      background: theme.white,
      height: 44,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      borderBottom: `1px solid ${theme.border}`,
      position: 'relative',
      paddingTop: 0,
    }}>
      {back && (
        <button onClick={onBack} style={{
          position: 'absolute', left: 16,
          background: 'none', border: 'none', fontSize: 22, color: theme.text,
          cursor: 'pointer', padding: 0,
        }}>{'<'}</button>
      )}
      <span style={{ fontSize: 17, fontWeight: 600, color: theme.text }}>{title}</span>
    </div>
  );
}

// 底部 TabBar - 增强导航功能
function WxTabBar({ active, onTab }) {
  const { navigateTo } = useNavigation();
  const tabs = [
    { id: 'home', label: '首页', icon: '🏠', screen: 'home' },
    { id: 'learn', label: '学习', icon: '📚', screen: 'learning' },
    { id: 'service', label: '服务', icon: '🔧', screen: 'lifeServices' },
    { id: 'profile', label: '我的', icon: '👤', screen: 'profile' },
  ];
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      height: 50, background: theme.white,
      borderTop: `1px solid ${theme.border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'space-around',
    }}>
      {tabs.map(t => (
        <button
          key={t.id}
          onClick={() => {
            navigateTo(t.screen);
            onTab?.(t.id);
          }}
          style={{
            background: 'none', border: 'none',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
            color: active === t.id ? theme.primary : theme.textMuted,
            cursor: 'pointer', fontSize: 10,
          }}>
          <span style={{ fontSize: 22 }}>{t.icon}</span>
          <span style={{ fontWeight: active === t.id ? 600 : 400 }}>{t.label}</span>
        </button>
      ))}
    </div>
  );
}

// 卡片组件
function Card({ children, style }) {
  return (
    <div style={{
      background: theme.white,
      borderRadius: 12,
      padding: 16,
      boxShadow: theme.cardShadow,
      ...style,
    }}>{children}</div>
  );
}

// 按钮组件
function Btn({ children, variant = 'primary', style, ...props }) {
  const variants = {
    primary: { background: theme.primary, color: '#fff' },
    secondary: { background: theme.primaryLight, color: theme.primary },
    outline: { background: 'transparent', color: theme.primary, border: `1px solid ${theme.primary}` },
    ghost: { background: 'transparent', color: theme.textSecondary },
  };
  return (
    <button style={{
      ...variants[variant],
      border: variant === 'outline' ? `1px solid ${theme.primary}` : 'none',
      borderRadius: 8,
      padding: '12px 24px',
      fontSize: 16,
      fontWeight: 600,
      width: '100%',
      cursor: 'pointer',
      ...style,
    }} {...props}>{children}</button>
  );
}

// 包装所有屏幕组件以支持导航
function ScreenWrapper({ children }) {
  return (
    <div style={{ width: '100%', height: '100%' }}>
      {children}
    </div>
  );
}

// 登录页 - 增强导航功能
function LoginScreen() {
  const { navigateTo } = useNavigation();

  return (
    <ScreenWrapper>
      <div style={{ background: theme.white, height: '100%', display: 'flex', flexDirection: 'column' }}>
        {/* Logo area */}
        <div style={{
          flex: 1, display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center', paddingTop: 40,
        }}>
          <div style={{
            width: 100, height: 100, borderRadius: 24,
            background: `linear-gradient(135deg, ${theme.primary}, ${theme.primaryDark})`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            marginBottom: 20,
            boxShadow: '0 8px 24px rgba(229,57,53,0.3)',
          }}>
            <span style={{ fontSize: 48, color: '#fff' }}>☭</span>
          </div>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: theme.text, marginBottom: 6 }}>
            南湾红帆党务智管家
          </h1>
          <p style={{ fontSize: 13, color: theme.textMuted }}>
            龙岗南湾街道 · 智慧党建平台
          </p>
        </div>

        {/* Login section */}
        <div style={{ padding: '0 32px 60px' }}>
          <button
            onClick={() => navigateTo('home')}
            style={{
              background: theme.primary,
              border: 'none',
              borderRadius: 8,
              padding: '12px 24px',
              fontSize: 16,
              fontWeight: 600,
              width: '100%',
              color: '#fff',
              cursor: 'pointer',
              marginBottom: 12,
            }}
          >
            <span style={{ marginRight: 8 }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="#fff">
                <path d="M8.69 12.5c0 .31-.03.6-.08.87-.1.53-.3 1-.6 1.38-.2.26-.45.47-.73.63a2.1 2.1 0 01-1.03.27c-.38 0-.73-.09-1.03-.27a2.1 2.1 0 01-.73-.63c-.3-.38-.5-.85-.6-1.38a5.8 5.8 0 010-1.74c.1-.53.3-1 .6-1.38.2-.26.45-.47.73-.63a2.1 2.1 0 011.03-.27c.38 0 .73.09 1.03.27.28.16.53.37.73.63.3.38.5.85.6 1.38.05.27.08.56.08.87z"/>
                <path d="M16.5 12.5c0 .31-.03.6-.08.87-.1.53-.3 1-.6 1.38-.2.26-.45.47-.73.63a2.1 2.1 0 01-1.03.27c-.38 0-.73-.09-1.03-.27a2.1 2.1 0 01-.73-.63c-.3-.38-.5-.85-.6-1.38a5.8 5.8 0 010-1.74c.1-.53.3-1 .6-1.38.2-.26.45-.47.73-.63a2.1 2.1 0 011.03-.27c.38 0 .73.09 1.03.27.28.16.53.37.73.63.3.38.5.85.6 1.38.05.27.08.56.08.87z"/>
              </svg>
            </span>
            微信授权登录
          </button>

          <p style={{
            textAlign: 'center', fontSize: 12, color: theme.textMuted,
            marginTop: 16, lineHeight: 1.6,
          }}>
            登录即表示同意《用户协议》和《隐私政策》
          </p>

          {/* 白名单校验失败提示 */}
          <div style={{
            marginTop: 20,
            padding: '12px 16px',
            background: '#FFF3E0',
            borderRadius: 8,
            borderLeft: `3px solid ${theme.warning}`,
            display: 'flex', alignItems: 'flex-start', gap: 8,
          }}>
            <span style={{ fontSize: 16, flexShrink: 0 }}>⚠️</span>
            <div>
              <p style={{ fontSize: 13, color: '#E65100', fontWeight: 600, marginBottom: 4 }}>
                白名单校验
              </p>
              <p style={{ fontSize: 12, color: '#BF360C', lineHeight: 1.5 }}>
                您的手机号暂不在本系统白名单内，请联系所在党支部管理员添加。
              </p>
            </div>
          </div>
        </div>
      </div>
    </ScreenWrapper>
  );
}

// 功能主页 - 增强导航功能
function HomeScreen() {
  const { navigateTo } = useNavigation();
  const [showYearPicker, setShowYearPicker] = React.useState(false);
  const [selectedYear, setSelectedYear] = React.useState('2026');
  const [showPopup, setShowPopup] = React.useState(true);

  const gridItems = [
    { icon: '📋', label: '党员档案', screen: 'profile' },
    { icon: '✅', label: '活动签到', screen: 'checkin' },
    { icon: '📚', label: '学习资源', screen: 'learning' },
    { icon: '🤖', label: 'AI画像', screen: 'aiProfile' },
    { icon: '📺', label: '直播活动', screen: 'liveActivity' },
    { icon: '📑', label: '资料审核', screen: 'archiveAudit' },
    { icon: '💼', label: '工作创业', screen: 'career' },
    { icon: '🏪', label: '便民服务', screen: 'lifeServices' },
    { icon: '📌', label: '处置指引', screen: 'disposal' },
  ];

  return (
    <ScreenWrapper>
      <div style={{ background: theme.bg, height: '100%', paddingBottom: 50, overflow: 'auto' }}>
        <WxNavBar title="南湾红帆" />

        {/* 年份选择器 */}
        <div style={{ padding: '12px 16px 0' }}>
          <div
            onClick={() => setShowYearPicker(!showYearPicker)}
            style={{
              background: theme.white, borderRadius: 10,
              padding: '10px 16px', display: 'flex', alignItems: 'center',
              justifyContent: 'space-between', boxShadow: theme.cardShadow,
            }}
          >
            <span style={{ fontSize: 14, color: theme.textSecondary }}>当前年度</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 18, fontWeight: 700, color: theme.primary }}>{selectedYear}</span>
              <span style={{ fontSize: 12, color: theme.textMuted }}>{showYearPicker ? '▾' : '▸'}</span>
            </div>
          </div>
          {showYearPicker && (
            <div style={{
              background: theme.white, borderRadius: 10, marginTop: 8,
              boxShadow: theme.cardShadow, overflow: 'hidden',
            }}>
              {['2026', '2025', '2024', '2023', '2022'].map(y => (
                <div
                  key={y}
                  onClick={() => { setSelectedYear(y); setShowYearPicker(false); }}
                  style={{
                    padding: '10px 16px',
                    fontSize: 15,
                    color: y === selectedYear ? theme.primary : theme.text,
                    fontWeight: y === selectedYear ? 600 : 400,
                    background: y === selectedYear ? theme.primaryLight : 'transparent',
                    cursor: 'pointer',
                  }}
                >{y}年</div>
              ))}
            </div>
          )}
        </div>

        {/* 党务智能问答入口 */}
        <div style={{ padding: '12px 16px 0' }}>
          <div
            onClick={() => navigateTo('aiQA')}
            style={{
              background: `linear-gradient(135deg, ${theme.primary}, #FF7043)`,
              borderRadius: 12, padding: '16px 20px',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              boxShadow: '0 4px 12px rgba(229,57,53,0.25)',
              cursor: 'pointer',
            }}>
            <div>
              <h3 style={{ fontSize: 16, fontWeight: 700, color: '#fff', marginBottom: 4 }}>
                党务智能问答
              </h3>
              <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.85)' }}>
                AI助手为您解答党务问题
              </p>
            </div>
            <div style={{
              background: 'rgba(255,255,255,0.2)', borderRadius: '50%',
              width: 44, height: 44, display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 22,
            }}>💬</div>
          </div>
        </div>

        {/* 8宫格功能导航 */}
        <div style={{ padding: '12px 16px 0' }}>
          <Card>
            <div style={{
              display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
              gap: 16,
            }}>
              {gridItems.map((item, i) => (
                <div
                  key={i}
                  onClick={() => navigateTo(item.screen)}
                  style={{
                    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
                    cursor: 'pointer',
                  }}>
                  <div style={{
                    width: 52, height: 52, borderRadius: 16,
                    background: i === 0 ? theme.primaryLight : '#F8F9FA',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 24,
                    boxShadow: i === 0 ? `0 2px 8px rgba(229,57,53,0.15)` : 'none',
                  }}>{item.icon}</div>
                  <span style={{ fontSize: 12, color: theme.textSecondary }}>{item.label}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* 订阅消息引导弹窗 */}
        {showPopup && (
          <div style={{
            position: 'absolute', inset: 0,
            background: 'rgba(0,0,0,0.5)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            zIndex: 100,
          }}>
            <div style={{
              background: theme.white, borderRadius: 16,
              padding: '24px 20px 20px', width: '85%',
              boxShadow: theme.cardShadowLg,
            }}>
              <div style={{ textAlign: 'center', marginBottom: 16 }}>
                <div style={{ fontSize: 40, marginBottom: 8 }}>🔔</div>
                <h3 style={{ fontSize: 17, fontWeight: 700, color: theme.text, marginBottom: 8 }}>
                  开启消息通知
                </h3>
                <p style={{ fontSize: 13, color: theme.textSecondary, lineHeight: 1.6 }}>
                  及时接收活动提醒、学习通知和支部消息，不再错过重要党务信息。
                </p>
              </div>
              <Btn onClick={() => setShowPopup(false)}>允许通知</Btn>
              <p
                onClick={() => setShowPopup(false)}
                style={{
                  textAlign: 'center', marginTop: 12,
                  fontSize: 13, color: theme.textMuted, cursor: 'pointer',
                }}
              >暂不开启</p>
            </div>
          </div>
        )}

        <WxTabBar active="home" />
      </div>
    </ScreenWrapper>
  );
}

// 个人信息页 - 增强导航功能
function ProfileScreen() {
  const { goBack, navigateTo } = useNavigation();

  return (
    <ScreenWrapper>
      <div style={{ background: theme.bg, height: '100%', paddingBottom: 50, overflow: 'auto' }}>
        <WxNavBar title="个人信息" back onBack={goBack} />

        {/* 红色头部 */}
        <div style={{
          background: `linear-gradient(135deg, ${theme.primary}, ${theme.primaryDark})`,
          padding: '20px 20px 30px',
          borderRadius: '0 0 20px 20px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <div style={{
              width: 64, height: 64, borderRadius: '50%',
              background: 'rgba(255,255,255,0.2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 28, border: '2px solid rgba(255,255,255,0.4)',
            }}>👤</div>
            <div>
              <h2 style={{ fontSize: 20, fontWeight: 700, color: '#fff', marginBottom: 4 }}>张伟</h2>
              <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)' }}>
                南湾街道第一党支部
              </p>
            </div>
          </div>
        </div>

        {/* 档案卡片 */}
        <div style={{ padding: '0 16px', marginTop: -16 }}>
          <Card>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h3 style={{ fontSize: 15, fontWeight: 700, color: theme.text }}>党员档案</h3>
              <span style={{
                background: '#E8F5E9', color: '#2E7D32',
                padding: '2px 10px', borderRadius: 10, fontSize: 12,
              }}>正式党员</span>
            </div>

            {[
              { label: '党员编号', value: '440307198503XXXX' },
              { label: '入党时间', value: '2019-03-15' },
              { label: '所属支部', value: '南湾街道第一党支部' },
              { label: '教育程度', value: '本科' },
              { label: '手机号码', value: '138****5678' },
            ].map((item, i) => (
              <div key={i} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '10px 0',
                borderBottom: i < 4 ? `1px solid ${theme.border}` : 'none',
              }}>
                <span style={{ fontSize: 13, color: theme.textSecondary }}>{item.label}</span>
                <span style={{ fontSize: 14, color: theme.text, fontWeight: 500 }}>{item.value}</span>
              </div>
            ))}
          </Card>
        </div>

        {/* 历年活动记录入口 */}
        <div style={{ padding: '16px 16px 0' }}>
          <Card
            onClick={() => navigateTo('activityHistory')}
            style={{ display: 'flex', alignItems: 'center', gap: 16, cursor: 'pointer' }}>
            <div style={{
              width: 80, height: 80, borderRadius: 8,
              background: '#F5F5F5',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              border: `1px solid ${theme.border}`,
            }}>
              <div style={{
                width: 60, height: 60,
                background: 'repeating-conic-gradient(#333 0% 25%, #fff 0% 50%) 50%/8px 8px',
              }} />
            </div>
            <div>
              <h4 style={{ fontSize: 14, fontWeight: 600, color: theme.text, marginBottom: 4 }}>
                党员身份二维码
              </h4>
              <p style={{ fontSize: 12, color: theme.textMuted }}>
                扫码核验党员身份
              </p>
            </div>
          </Card>
        </div>

        {/* 操作按钮 */}
        <div style={{ padding: '16px 16px 0' }}>
          <Btn
            variant="secondary"
            onClick={() => navigateTo('activityHistory')}
          >
            查看活动参加情况
          </Btn>
        </div>

        <WxTabBar active="profile" />
      </div>
    </ScreenWrapper>
  );
}

// 历年活动记录页 - 增强导航功能
function ActivityHistoryScreen() {
  const { goBack } = useNavigation();
  const [expandedYear, setExpandedYear] = React.useState('2025');

  const years = {
    '2025': [
      { date: '2025-04-12', location: '南湾街道党群服务中心', theme: '2025年第一季度党员大会', hasPhoto: true },
      { date: '2025-03-08', location: '南湾社区公园', theme: '学雷锋志愿服务日活动', hasPhoto: true },
      { date: '2025-01-15', location: '线上会议', theme: '年度组织生活会', hasPhoto: false },
    ],
    '2024': [
      { date: '2024-12-20', location: '南湾街道会议室', theme: '年度民主评议党员', hasPhoto: true },
      { date: '2024-07-01', location: '南湾街道党群服务中心', theme: '七一表彰大会', hasPhoto: true },
      { date: '2024-03-15', location: '线上学习', theme: '全国两会精神学习', hasPhoto: false },
    ],
    '2023': [
      { date: '2023-11-10', location: '南湾社区', theme: '主题教育实践活动', hasPhoto: true },
      { date: '2023-07-01', location: '南湾街道', theme: '建党102周年庆祝活动', hasPhoto: true },
    ],
  };

  return (
    <ScreenWrapper>
      <div style={{ background: theme.bg, height: '100%', paddingBottom: 50, overflow: 'auto' }}>
        <WxNavBar title="历年活动记录" back onBack={goBack} />

        {Object.entries(years).map(([year, activities]) => (
          <div key={year} style={{ marginBottom: 12 }}>
            <div
              onClick={() => setExpandedYear(expandedYear === year ? null : year)}
              style={{
                background: theme.white,
                padding: '14px 16px',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                cursor: 'pointer',
                borderBottom: expandedYear === year ? `1px solid ${theme.border}` : 'none',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{
                  width: 40, height: 40, borderRadius: 10,
                  background: expandedYear === year ? theme.primary : theme.primaryLight,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: expandedYear === year ? '#fff' : theme.primary,
                  fontSize: 14, fontWeight: 700,
                }}>{year}</div>
                <span style={{ fontSize: 14, color: theme.textSecondary }}>
                  共 {activities.length} 次活动
                </span>
              </div>
              <span style={{ fontSize: 12, color: theme.textMuted }}>
                {expandedYear === year ? '▾' : '▸'}
              </span>
            </div>

            {expandedYear === year && activities.map((act, i) => (
              <div key={i} style={{
                background: theme.white,
                padding: '14px 16px',
                borderBottom: `1px solid ${theme.border}`,
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <h4 style={{ fontSize: 14, fontWeight: 600, color: theme.text, flex: 1 }}>
                    {act.theme}
                  </h4>
                  {act.hasPhoto && (
                    <div style={{
                      width: 60, height: 44, borderRadius: 6,
                      background: `linear-gradient(135deg, #FFE0B2, #FFCC80)`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 18, flexShrink: 0, marginLeft: 12,
                    }}>📷</div>
                  )}
                </div>
                <div style={{ display: 'flex', gap: 16 }}>
                  <span style={{ fontSize: 12, color: theme.textMuted }}>📅 {act.date}</span>
                  <span style={{ fontSize: 12, color: theme.textMuted }}>📍 {act.location}</span>
                </div>
              </div>
            ))}
          </div>
        ))}

        <WxTabBar active="home" />
      </div>
    </ScreenWrapper>
  );
}

// 活动签到页 - 增强导航功能
function CheckinScreen() {
  const { goBack } = useNavigation();
  const [status, setStatus] = React.useState('success'); // success | failed | ended

  const statusConfig = {
    success: {
      icon: '✅',
      title: '签到成功',
      desc: '您已完成本次活动的签到',
      color: theme.success,
      bg: '#E8F5E9',
    },
    failed: {
      icon: '❌',
      title: '签到失败',
      desc: '请确认您已在活动现场，并重新扫码',
      color: '#F44336',
      bg: '#FFEBEE',
    },
    ended: {
      icon: '⏰',
      title: '活动已结束',
      desc: '该活动签到通道已关闭',
      color: theme.warning,
      bg: '#FFF3E0',
    },
  };

  const s = statusConfig[status];

  return (
    <ScreenWrapper>
      <div style={{ background: theme.bg, height: '100%', display: 'flex', flexDirection: 'column' }}>
        <WxNavBar title="活动签到" back onBack={goBack} />

        <div style={{ padding: 20, flex: 1 }}>
          {/* 活动信息 */}
          <Card style={{ marginBottom: 20 }}>
            <h3 style={{ fontSize: 16, fontWeight: 700, color: theme.text, marginBottom: 12 }}>
              2025年第一季度党员大会
            </h3>
            <div style={{ fontSize: 13, color: theme.textSecondary, lineHeight: 2 }}>
              <div>📅 2025-04-12 14:00</div>
              <div>📍 南湾街道党群服务中心 3楼会议室</div>
              <div>👥 应到 56 人</div>
            </div>
          </Card>

          {/* 状态展示 */}
          <div style={{
            background: s.bg,
            borderRadius: 16,
            padding: '32px 20px',
            textAlign: 'center',
            marginBottom: 20,
          }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>{s.icon}</div>
            <h2 style={{ fontSize: 22, fontWeight: 700, color: s.color, marginBottom: 8 }}>
              {s.title}
            </h2>
            <p style={{ fontSize: 14, color: theme.textSecondary }}>{s.desc}</p>
          </div>

          {/* 签到时间 */}
          <div style={{
            background: theme.white, borderRadius: 12, padding: 16,
            textAlign: 'center',
          }}>
            <p style={{ fontSize: 12, color: theme.textMuted, marginBottom: 4 }}>签到时间</p>
            <p style={{ fontSize: 24, fontWeight: 700, color: theme.text, fontFamily: 'monospace' }}>
              14:05:32
            </p>
          </div>

          {/* 状态切换（原型演示用） */}
          <div style={{ marginTop: 20, display: 'flex', gap: 8 }}>
            {Object.entries(statusConfig).map(([key, val]) => (
              <button
                key={key}
                onClick={() => setStatus(key)}
                style={{
                  flex: 1, padding: '8px 0', borderRadius: 8, border: 'none',
                  fontSize: 12, cursor: 'pointer',
                  background: status === key ? val.color : '#F5F5F5',
                  color: status === key ? '#fff' : theme.textMuted,
                  fontWeight: status === key ? 600 : 400,
                }}
              >{val.title}</button>
            ))}
          </div>
        </div>
      </div>
    </ScreenWrapper>
  );
}

// 学习资源列表页 - 增强导航功能
function LearningScreen() {
  const { goBack, navigateTo } = useNavigation();
  const [activeTab, setActiveTab] = React.useState('required');

  const courses = {
    required: [
      { name: '习近平新时代中国特色社会主义思想概论', type: '视频课程', duration: '45分钟', status: 'completed', progress: 100 },
      { name: '中国共产党纪律处分条例解读', type: '图文学习', duration: '30分钟', status: 'in-progress', progress: 60 },
      { name: '党的二十大精神专题学习', type: '视频课程', duration: '60分钟', status: 'not-started', progress: 0 },
      { name: '党章党规党纪学习', type: '在线测试', duration: '20分钟', status: 'completed', progress: 100 },
    ],
    optional: [
      { name: '基层治理现代化案例分析', type: '视频课程', duration: '35分钟', status: 'not-started', progress: 0 },
      { name: '乡村振兴政策解读', type: '图文学习', duration: '25分钟', status: 'in-progress', progress: 30 },
      { name: '党员志愿服务技能提升', type: '视频课程', duration: '40分钟', status: 'not-started', progress: 0 },
    ],
  };

  const statusMap = {
    completed: { label: '已完成', color: theme.success, bg: '#E8F5E9' },
    'in-progress': { label: '学习中', color: theme.primary, bg: theme.primaryLight },
    'not-started': { label: '未开始', color: theme.textMuted, bg: '#F5F5F5' },
  };

  return (
    <ScreenWrapper>
      <div style={{ background: theme.bg, height: '100%', paddingBottom: 50, overflow: 'auto' }}>
        <WxNavBar title="学习资源" back onBack={goBack} />

        {/* Tab 切换 */}
        <div style={{
          display: 'flex', background: theme.white,
          borderBottom: `1px solid ${theme.border}`,
        }}>
          {[
            { id: 'required', label: '必修课程' },
            { id: 'optional', label: '选修课程' },
          ].map(tab => (
            <div
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                flex: 1, textAlign: 'center', padding: '12px 0',
                fontSize: 15, fontWeight: activeTab === tab.id ? 700 : 400,
                color: activeTab === tab.id ? theme.primary : theme.textSecondary,
                borderBottom: activeTab === tab.id ? `2px solid ${theme.primary}` : 'none',
                cursor: 'pointer',
              }}
            >{tab.label}</div>
          ))}
        </div>

        {/* 课程列表 */}
        <div style={{ padding: 12 }}>
          {courses[activeTab].map((course, i) => {
            const st = statusMap[course.status];
            return (
              <Card
                key={i}
                onClick={() => navigateTo('courseDetail')}
                style={{
                  marginBottom: 12,
                  cursor: 'pointer',
                }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                  <div style={{ flex: 1, paddingRight: 12 }}>
                    <h4 style={{ fontSize: 14, fontWeight: 600, color: theme.text, lineHeight: 1.5, marginBottom: 8 }}>
                      {course.name}
                    </h4>
                    <div style={{ display: 'flex', gap: 12, marginBottom: 8 }}>
                      <span style={{ fontSize: 12, color: theme.textMuted }}>📖 {course.type}</span>
                      <span style={{ fontSize: 12, color: theme.textMuted }}>⏱ {course.duration}</span>
                    </div>
                  </div>
                  <span style={{
                    padding: '2px 10px', borderRadius: 10, fontSize: 11,
                    background: st.bg, color: st.color, fontWeight: 500, whiteSpace: 'nowrap',
                  }}>{st.label}</span>
                </div>

                {/* 进度条 */}
                {course.status === 'in-progress' && (
                  <div style={{
                    height: 4, borderRadius: 2, background: '#F5F5F5', overflow: 'hidden',
                  }}>
                    <div style={{
                      height: '100%', width: `${course.progress}%`,
                      background: theme.primary, borderRadius: 2,
                    }} />
                  </div>
                )}

                {course.status === 'completed' && (
                  <div style={{
                    display: 'flex', alignItems: 'center', gap: 4,
                    fontSize: 12, color: theme.success,
                  }}>✓ 已完成</div>
                )}
              </Card>
            );
          })}
        </div>

        <WxTabBar active="learn" />
      </div>
    </ScreenWrapper>
  );
}

// 学习详情页 - 增强导航功能
function CourseDetailScreen() {
  const { goBack } = useNavigation();

  return (
    <ScreenWrapper>
      <div style={{ background: '#1A1A1A', height: '100%', display: 'flex', flexDirection: 'column' }}>
        {/* 视频播放区 */}
        <div style={{
          background: '#000',
          aspectRatio: '16/9',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          position: 'relative',
        }}>
          <div style={{ fontSize: 60, opacity: 0.3 }}>▶</div>
          {/* 播放进度 */}
          <div style={{
            position: 'absolute', bottom: 0, left: 0, right: 0,
            height: 4, background: 'rgba(255,255,255,0.2)',
          }}>
            <div style={{
              width: '35%', height: '100%', background: theme.primary,
            }} />
          </div>
          {/* 时间码 */}
          <div style={{
            position: 'absolute', bottom: 12, right: 12,
            background: 'rgba(0,0,0,0.6)', borderRadius: 4,
            padding: '2px 8px', fontSize: 12, color: '#fff',
          }}>15:42 / 45:00</div>
        </div>

        {/* 课程信息 */}
        <div style={{
          flex: 1, background: theme.white,
          borderRadius: '20px 20px 0 0',
          marginTop: -20,
          padding: '20px 16px 16px',
          overflow: 'auto',
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <button onClick={goBack} style={{
              background: 'none', border: 'none', fontSize: 22, color: theme.text,
              cursor: 'pointer', padding: 0, marginRight: 16,
            }}>{'<'}</button>
            <h2 style={{ fontSize: 18, fontWeight: 700, color: theme.text, flex: 1, textAlign: 'center', marginLeft: -30 }}>
              习近平新时代中国特色社会主义思想概论
            </h2>
          </div>

          <div style={{
            display: 'flex', gap: 16, marginBottom: 20,
            padding: '12px 0', borderTop: `1px solid ${theme.border}`, borderBottom: `1px solid ${theme.border}`,
          }}>
            <div style={{ textAlign: 'center', flex: 1 }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: theme.primary }}>35%</div>
              <div style={{ fontSize: 11, color: theme.textMuted }}>学习进度</div>
            </div>
            <div style={{ textAlign: 'center', flex: 1 }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: theme.text }}>45分钟</div>
              <div style={{ fontSize: 11, color: theme.textMuted }}>总时长</div>
            </div>
            <div style={{ textAlign: 'center', flex: 1 }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: theme.success }}>85分</div>
              <div style={{ fontSize: 11, color: theme.textMuted }}>上次测试</div>
            </div>
          </div>

          <h3 style={{ fontSize: 15, fontWeight: 600, color: theme.text, marginBottom: 12 }}>
            课程目录
          </h3>
          {[
            { title: '第一章 新时代中国特色社会主义思想的形成', done: true },
            { title: '第二章 新时代我国社会主要矛盾的变化', done: true },
            { title: '第三章 坚持和发展中国特色社会主义', done: false, current: true },
            { title: '第四章 全面建设社会主义现代化国家', done: false },
            { title: '第五章 推进国家治理体系和治理能力现代化', done: false },
          ].map((ch, i) => (
            <div key={i} style={{
              padding: '10px 0',
              borderBottom: `1px solid ${theme.border}`,
              display: 'flex', alignItems: 'center', gap: 12,
              opacity: ch.done ? 1 : ch.current ? 1 : 0.5,
            }}>
              <span style={{
                width: 24, height: 24, borderRadius: '50%',
                background: ch.done ? theme.success : ch.current ? theme.primary : '#E0E0E0',
                color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 12, flexShrink: 0,
              }}>
                {ch.done ? '✓' : i + 1}
              </span>
              <span style={{ fontSize: 13, color: theme.text }}>{ch.title}</span>
            </div>
          ))}
        </div>
      </div>
    </ScreenWrapper>
  );
}

// 档案智能审核（与 PC 门类口径一致，小程序轻量镜像）
function ArchiveAuditScreen() {
  const { goBack } = useNavigation();
  const mini = [
    { label: '待审资料包', value: '23', c: theme.warning },
    { label: '已通过', value: '156', c: theme.success },
    { label: '规则问题', value: '8', c: theme.primary },
  ];
  const issues = [
    { cat: '党员档案资料', title: '「三会一课」导出包 2025-Q1', issue: '缺少完整性校验摘要', sev: 'high' },
    { cat: '书刊资料', title: '《基层党建实务》2024-2', issue: '版权页与编目不一致', sev: 'mid' },
    { cat: '信息档案', title: '依申请公开登记册（2024）', issue: '保管期限未标注', sev: 'high' },
  ];
  return (
    <ScreenWrapper>
      <div style={{ background: theme.bg, height: '100%', paddingBottom: 50, overflow: 'auto' }}>
        <WxNavBar title="档案智能审核" back onBack={goBack} />
        <div style={{ padding: 16 }}>
          <p style={{ fontSize: 12, color: theme.textMuted, lineHeight: 1.65, marginBottom: 14 }}>
            审核对象为<strong style={{ color: theme.text }}>资料门类与资料包</strong>（非按人维度）。完整规则与导出请在 PC 管理端操作（演示）。
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 16 }}>
            {mini.map((s) => (
              <Card key={s.label} style={{ textAlign: 'center', padding: '12px 8px' }}>
                <div style={{ fontSize: 11, color: theme.textMuted, marginBottom: 4 }}>{s.label}</div>
                <div style={{ fontSize: 20, fontWeight: 700, color: s.c }}>{s.value}</div>
              </Card>
            ))}
          </div>
          <Card style={{ marginBottom: 16 }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 8 }}>当前标准（版本）</h3>
            <p style={{ fontSize: 13, fontWeight: 600, color: theme.text }}>党务资料多门类数字化审核细则 v2.3</p>
            <p style={{ fontSize: 12, color: theme.textMuted, marginTop: 6, lineHeight: 1.5 }}>党员档案资料、书刊、信息档案等 · 更新 2025-03-01</p>
          </Card>
          <Card style={{ marginBottom: 16 }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>门类问题示例</h3>
            {issues.map((it, i) => (
              <div key={i} style={{ paddingBottom: 12, marginBottom: 12, borderBottom: i < issues.length - 1 ? `1px solid ${theme.border}` : 'none' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <span style={{ fontSize: 10, color: theme.textSecondary, background: '#F5F5F5', padding: '2px 8px', borderRadius: 6 }}>{it.cat}</span>
                  <span style={{ fontSize: 11, fontWeight: 600, color: it.sev === 'high' ? theme.primary : theme.warning }}>{it.sev === 'high' ? '严重' : '一般'}</span>
                </div>
                <p style={{ fontSize: 13, fontWeight: 600, color: theme.text, marginBottom: 4 }}>{it.title}</p>
                <p style={{ fontSize: 12, color: theme.textSecondary, lineHeight: 1.5 }}>{it.issue}</p>
              </div>
            ))}
          </Card>
          <Btn variant="primary" onClick={() => alert('已刷新审核队列（演示）')}>刷新队列</Btn>
          <p style={{ fontSize: 12, color: theme.textMuted, textAlign: 'center', marginTop: 12, cursor: 'pointer' }} onClick={() => alert('请在 PC 管理端导出完整 Word 报告（演示）')}>导出说明</p>
        </div>
        <WxTabBar active="home" />
      </div>
    </ScreenWrapper>
  );
}

// AI智能画像页 - 增强导航功能
function AIProfileScreen() {
  const { goBack } = useNavigation();
  const activityStats = [
    { label: '参与活动', value: '12场' },
    { label: '活动出勤率', value: '86%' },
    { label: '签到合规率', value: '92%' },
  ];
  const liveStats = [
    { label: '参与直播', value: '6场' },
    { label: '录播观看', value: '38次' },
    { label: '完成率', value: '84%' },
  ];
  const monthlyTrend = [
    { month: '2025-11', activities: 3, live: 1, replay: 9 },
    { month: '2025-12', activities: 4, live: 2, replay: 11 },
    { month: '2026-01', activities: 5, live: 1, replay: 14 },
    { month: '2026-02', activities: 6, live: 2, replay: 16 },
    { month: '2026-03', activities: 5, live: 2, replay: 18 },
    { month: '2026-04', activities: 7, live: 3, replay: 21 },
  ];

  return (
    <ScreenWrapper>
      <div style={{ background: theme.bg, height: '100%', paddingBottom: 50, overflow: 'auto' }}>
        <WxNavBar title="AI智能画像" back onBack={goBack} />

        <div style={{ padding: 16 }}>
          <p style={{ fontSize: 12, color: theme.textMuted, lineHeight: 1.55, marginBottom: 14 }}>
            党员端为参与自画像（演示）。支部治理、按人检索及月度趋势维护见 PC「AI 画像管理」。
          </p>
          {/* 综合评分 */}
          <Card style={{
            background: `linear-gradient(135deg, ${theme.primary}, #FF7043)`,
            textAlign: 'center', padding: '24px 16px', marginBottom: 16,
          }}>
            <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)', marginBottom: 8 }}>综合评分</p>
            <div style={{ fontSize: 52, fontWeight: 800, color: '#fff', lineHeight: 1 }}>85</div>
            <div style={{
              display: 'inline-block', marginTop: 8,
              background: 'rgba(255,255,255,0.2)', borderRadius: 20,
              padding: '4px 16px', fontSize: 14, color: '#fff', fontWeight: 600,
            }}>优秀</div>
            <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 12 }}>
              排名前 15% · 全支部共 56 名党员
            </p>
          </Card>

          {/* 雷达图模拟 */}
          <Card style={{ marginBottom: 16 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: theme.text, marginBottom: 16 }}>
              五维能力评估
            </h3>
            <div style={{
              position: 'relative', width: 220, height: 220, margin: '0 auto 16px',
            }}>
              <svg width="220" height="220" viewBox="0 0 220 220">
                {/* 背景网格 */}
                {[40, 70, 100].map(r => (
                  <polygon key={r}
                    points="110,30 180,85 155,175 65,175 40,85"
                    fill="none" stroke="#E0E0E0" strokeWidth="0.5"
                    transform={`scale(${r/100}) translate(${110*(1-r/100)}, ${110*(1-r/100)})`}
                  />
                ))}
                {/* 数据区域 */}
                <polygon
                  points="110,42 172,90 145,168 72,165 48,95"
                  fill="rgba(229,57,53,0.15)" stroke={theme.primary} strokeWidth="2"
                />
                {/* 数据点 */}
                {[[110,42], [172,90], [145,168], [72,165], [48,95]].map(([x,y], i) => (
                  <circle key={i} cx={x} cy={y} r="4" fill={theme.primary} />
                ))}
                {/* 标签 */}
                <text x="110" y="18" textAnchor="middle" fontSize="10" fill={theme.textSecondary}>学习参与度</text>
                <text x="195" y="95" textAnchor="start" fontSize="10" fill={theme.textSecondary}>活动出勤率</text>
                <text x="155" y="188" textAnchor="start" fontSize="10" fill={theme.textSecondary}>政治理论</text>
                <text x="55" y="188" textAnchor="end" fontSize="10" fill={theme.textSecondary}>志愿服务</text>
                <text x="25" y="95" textAnchor="end" fontSize="10" fill={theme.textSecondary}>民主评议</text>
              </svg>
            </div>
            {/* 维度得分 */}
            {[
              { label: '学习参与度', score: 92 },
              { label: '活动出勤率', score: 88 },
              { label: '政治理论掌握', score: 80 },
              { label: '志愿服务时长', score: 75 },
              { label: '民主评议结果', score: 90 },
            ].map((dim, i) => (
              <div key={i} style={{ marginBottom: 8 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontSize: 12, color: theme.textSecondary }}>{dim.label}</span>
                  <span style={{ fontSize: 12, fontWeight: 600, color: theme.text }}>{dim.score}分</span>
                </div>
                <div style={{ height: 6, borderRadius: 3, background: '#F5F5F5' }}>
                  <div style={{
                    height: '100%', width: `${dim.score}%`,
                    background: dim.score >= 85 ? theme.primary : dim.score >= 70 ? theme.warning : '#9E9E9E',
                    borderRadius: 3,
                  }} />
                </div>
              </div>
            ))}
          </Card>

          {/* AI总结 */}
          <Card style={{ marginBottom: 16 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: theme.text, marginBottom: 12 }}>
              🤖 AI 分析总结
            </h3>
            <p style={{ fontSize: 13, color: theme.textSecondary, lineHeight: 1.8 }}>
              演示：当前登录党员在 2026 年度学习参与位居支部前列，活动出勤率良好。
              政治理论学习扎实，志愿服务仍有提升空间。可与 PC「AI 画像管理」中支部统计对照查看。
            </p>
          </Card>

          <Card style={{ marginBottom: 16 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: theme.text, marginBottom: 8 }}>
              📈 近 6 个月趋势（演示）
            </h3>
            <p style={{ fontSize: 12, color: theme.textMuted, marginBottom: 10 }}>活动场次 · 直播场次 · 录播观看次数</p>
            {(() => {
              const W = 320;
              const H = 200;
              const padL = 34;
              const padR = 8;
              const padT = 36;
              const padB = 28;
              const innerW = W - padL - padR;
              const innerH = H - padT - padB;
              const data = monthlyTrend;
              const n = data.length;
              const maxY = Math.max(8, ...data.flatMap((d) => [d.activities, d.live, d.replay])) * 1.08;
              const xAt = (i) => padL + (i / (n - 1)) * innerW;
              const yAt = (v) => padT + innerH - (v / maxY) * innerH;
              const line = (key) => data.map((d, i) => `${i ? 'L' : 'M'}${xAt(i).toFixed(1)},${yAt(d[key]).toFixed(1)}`).join(' ');
              const area = (key) => {
                let d = `M${xAt(0)},${yAt(data[0][key])}`;
                for (let i = 1; i < n; i++) d += ` L${xAt(i)},${yAt(data[i][key])}`;
                const y0 = padT + innerH;
                d += ` L${xAt(n - 1)},${y0} L${xAt(0)},${y0} Z`;
                return d;
              };
              const monthLab = (m) => `${parseInt(m.split('-')[1], 10)}月`;
              const series = [
                { key: 'activities', c: theme.primary, g: 'jsxMobTrendA' },
                { key: 'live', c: '#2563EB', g: 'jsxMobTrendL' },
                { key: 'replay', c: theme.success, g: 'jsxMobTrendR' },
              ];
              return (
                <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{ display: 'block', maxWidth: 360 }}>
                  <defs>
                    {series.map((s) => (
                      <linearGradient key={s.g} id={s.g} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={s.c} stopOpacity="0.2" />
                        <stop offset="100%" stopColor={s.c} stopOpacity="0" />
                      </linearGradient>
                    ))}
                  </defs>
                  {[0, 0.5, 1].map((t, i) => {
                    const y = padT + innerH * (1 - t);
                    return (
                      <g key={i}>
                        <line x1={padL} y1={y} x2={W - padR} y2={y} stroke="#EDE9E4" strokeWidth="1" />
                        <text x={padL - 4} y={y + 3} textAnchor="end" fontSize={9} fill={theme.textMuted}>{t === 0 ? 0 : Math.round(maxY * t)}</text>
                      </g>
                    );
                  })}
                  {series.map((s) => <path key={s.g} d={area(s.key)} fill={`url(#${s.g})`} />)}
                  {series.map((s) => <path key={s.key} d={line(s.key)} fill="none" stroke={s.c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />)}
                  {series.map((s) => data.map((d, i) => <circle key={`${s.key}-${i}`} cx={xAt(i)} cy={yAt(d[s.key])} r="3.5" fill="#fff" stroke={s.c} strokeWidth="1.8" />))}
                  {data.map((d, i) => <text key={i} x={xAt(i)} y={H - 8} textAnchor="middle" fontSize={9} fill={theme.textSecondary}>{monthLab(d.month)}</text>)}
                  <g transform={`translate(${padL}, 10)`}>
                    {series.map((s) => (
                      <g key={s.key} transform={`translate(${s.key === 'activities' ? 0 : s.key === 'live' ? 88 : 176}, 0)`}>
                        <rect width="8" height="8" rx="1.5" fill={s.c} />
                        <text x="11" y="7.5" fontSize={9} fill={theme.text}>{s.key === 'activities' ? '活动' : s.key === 'live' ? '直播' : '录播'}</text>
                      </g>
                    ))}
                  </g>
                </svg>
              );
            })()}
            <p style={{ fontSize: 12, color: theme.textSecondary, marginTop: 8 }}>累计直播观看约 540 分钟（演示）。</p>
          </Card>

          <Card style={{ marginBottom: 16 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: theme.text, marginBottom: 12 }}>
              📅 活动参与数据（演示）
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 10 }}>
              {activityStats.map((item) => (
                <div key={item.label} style={{ background: theme.bg, border: `1px solid ${theme.border}`, borderRadius: 8, padding: '8px 6px', textAlign: 'center' }}>
                  <div style={{ fontSize: 10, color: theme.textMuted, marginBottom: 4 }}>{item.label}</div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: theme.text }}>{item.value}</div>
                </div>
              ))}
            </div>
            <p style={{ fontSize: 12, color: theme.textSecondary }}>最近活动：主题党日专题学习（签到正常）</p>
          </Card>

          <Card style={{ marginBottom: 16 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: theme.text, marginBottom: 12 }}>
              📺 直播与录播（演示）
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 10 }}>
              {liveStats.map((item) => (
                <div key={item.label} style={{ background: theme.bg, border: `1px solid ${theme.border}`, borderRadius: 8, padding: '8px 6px', textAlign: 'center' }}>
                  <div style={{ fontSize: 10, color: theme.textMuted, marginBottom: 4 }}>{item.label}</div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: theme.text }}>{item.value}</div>
                </div>
              ))}
            </div>
            <p style={{ fontSize: 12, color: theme.textSecondary }}>最近直播：二十大精神宣讲直播（观看完成）</p>
          </Card>

          <Btn variant="primary">立即更新画像</Btn>
        </div>

        <WxTabBar active="home" />
      </div>
    </ScreenWrapper>
  );
}

// 直播活动详情页 - 增强导航功能
function LiveActivityScreen() {
  const { goBack } = useNavigation();
  const [liveStatus, setLiveStatus] = React.useState('not-started');

  const config = {
    'not-started': { btnText: '活动未开始', btnVariant: 'secondary', btnDisabled: true, tag: '未开始', tagBg: '#FFF3E0', tagColor: '#E65100' },
    live: { btnText: '进入直播间', btnVariant: 'primary', btnDisabled: false, tag: '直播中', tagBg: '#FFEBEE', tagColor: '#E53935' },
    ended: { btnText: '查看回放', btnVariant: 'outline', btnDisabled: false, tag: '已结束', tagBg: '#F5F5F5', tagColor: '#999' },
  };

  const c = config[liveStatus];

  return (
    <ScreenWrapper>
      <div style={{ background: theme.bg, height: '100%', paddingBottom: 50, overflow: 'auto' }}>
        <WxNavBar title="直播活动" back onBack={goBack} />

        <div style={{ padding: 16 }}>
          {/* 活动状态标签 */}
          <div style={{
            display: 'inline-block', padding: '4px 14px', borderRadius: 20,
            background: c.tagBg, color: c.tagColor, fontSize: 13, fontWeight: 600,
            marginBottom: 16,
          }}>{c.tag}</div>

          {/* 活动信息卡片 */}
          <Card style={{ marginBottom: 16 }}>
            <h2 style={{ fontSize: 18, fontWeight: 700, color: theme.text, marginBottom: 16, lineHeight: 1.4 }}>
              南湾街道2025年度党员培训直播
            </h2>

            <div style={{ fontSize: 14, color: theme.textSecondary, lineHeight: 2.2 }}>
              <div>📅 2025年6月15日（周日）14:00</div>
              <div>👨‍🏫 主讲人：李明教授 · 省委党校</div>
              <div>⏱ 预计时长：120分钟</div>
              <div>👥 已报名：128人</div>
            </div>
          </Card>

          {/* 操作按钮 */}
          <div style={{ marginBottom: 16 }}>
            <Btn variant={c.btnVariant} disabled={c.btnDisabled}>
              {c.btnText}
            </Btn>
          </div>

          <Btn variant="secondary" style={{ marginBottom: 16 }}>
            立即签到
          </Btn>

          {/* 签到规则 */}
          <Card style={{ marginBottom: 16 }}>
            <h4 style={{ fontSize: 14, fontWeight: 600, color: theme.text, marginBottom: 12 }}>
              签到规则
            </h4>
            <p style={{ fontSize: 13, color: theme.textSecondary, lineHeight: 1.8 }}>
              • 活动开始前15分钟开放签到<br/>
              • 签到后进入直播间观看<br/>
              • 观看时长满60分钟计为有效参会<br/>
              • 未签到者不计入出勤记录
            </p>
          </Card>

          {/* 状态切换（原型演示用） */}
          <div style={{ display: 'flex', gap: 8 }}>
            {Object.entries(config).map(([key, val]) => (
              <button
                key={key}
                onClick={() => setLiveStatus(key)}
                style={{
                  flex: 1, padding: '8px 0', borderRadius: 8, border: 'none',
                  fontSize: 12, cursor: 'pointer',
                  background: liveStatus === key ? theme.primary : '#F5F5F5',
                  color: liveStatus === key ? '#fff' : theme.textMuted,
                  fontWeight: liveStatus === key ? 600 : 400,
                }}
              >{val.tag}</button>
            ))}
          </div>
        </div>

        <WxTabBar active="home" />
      </div>
    </ScreenWrapper>
  );
}

// 党务智能问答页 - 增强导航功能
function AIQAScreen() {
  const { goBack } = useNavigation();
  const messages = [
    { role: 'ai', text: '您好！我是南湾红帆党务智能助手，请问有什么可以帮您？' },
    { role: 'user', text: '发展党员的基本程序是什么？' },
    { role: 'ai', text: '发展党员的基本程序包括5个阶段25个步骤：\n\n1️⃣ 申请入党阶段\n   - 递交入党申请书\n   - 党组织派人谈话\n\n2️⃣ 入党积极分子确定和培养教育\n   - 推荐和确定入党积极分子\n   - 上级党委备案\n\n3️⃣ 发展对象确定和考察\n   - 确定发展对象\n   - 报上级党委备案\n   - 确定入党介绍人\n\n4️⃣ 预备党员接收\n   - 支部委员会审查\n   - 上级党委预审\n   - 填写入党志愿书\n   - 支部大会讨论\n\n5️⃣ 预备党员教育考察和转正\n   - 编入党支部和党小组\n   - 入党宣誓\n   - 继续教育考察\n   - 提出转正申请', },
  ];

  return (
    <ScreenWrapper>
      <div style={{ background: '#F5F5F5', height: '100%', display: 'flex', flexDirection: 'column' }}>
        <WxNavBar title="党务智能问答" back onBack={goBack} />

        {/* 聊天区域 */}
        <div style={{ flex: 1, overflow: 'auto', padding: '12px 16px' }}>
          {messages.map((msg, i) => (
            <div key={i} style={{
              display: 'flex',
              justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start',
              marginBottom: 12,
            }}>
              {msg.role === 'ai' && (
                <div style={{
                  width: 32, height: 32, borderRadius: '50%',
                  background: theme.primary,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 16, marginRight: 8, flexShrink: 0, marginTop: 4,
                }}>🤖</div>
              )}
              <div style={{
                maxWidth: '80%', padding: '10px 14px',
                borderRadius: msg.role === 'user' ? '12px 12px 2px 12px' : '12px 12px 12px 2px',
                background: msg.role === 'user' ? theme.primary : theme.white,
                color: msg.role === 'user' ? '#fff' : theme.text,
                fontSize: 14, lineHeight: 1.6,
                whiteSpace: 'pre-wrap',
              }}>{msg.text}</div>
            </div>
          ))}
        </div>

        {/* 输入栏 */}
        <div style={{
          background: theme.white,
          borderTop: `1px solid ${theme.border}`,
          padding: '10px 16px 30px',
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <div style={{
            flex: 1, background: '#F5F5F5', borderRadius: 20,
            padding: '8px 16px', fontSize: 14, color: theme.textMuted,
          }}>请输入您的问题...</div>
          <div style={{
            width: 36, height: 36, borderRadius: '50%',
            background: theme.primary,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: '#fff', fontSize: 18,
          }}>↑</div>
        </div>
      </div>
    </ScreenWrapper>
  );
}

// 工作创业服务页 - 增强导航功能
function CareerScreen() {
  const { goBack } = useNavigation();

  return (
    <ScreenWrapper>
      <div style={{ background: theme.bg, height: '100%', paddingBottom: 50, overflow: 'auto' }}>
        <WxNavBar title="工作创业服务" back onBack={goBack} />

        <div style={{ padding: 16 }}>
          {/* 就业信息 */}
          <h3 style={{ fontSize: 15, fontWeight: 700, color: theme.text, marginBottom: 12 }}>
            最新招聘信息
          </h3>

          {[
            { title: '社区网格员', salary: '5000-8000元/月', location: '南湾街道', tags: ['五险一金', '双休'] },
            { title: '党群服务中心社工', salary: '6000-9000元/月', location: '龙岗区', tags: ['带薪年假', '节日福利'] },
            { title: '街道办行政助理', salary: '4500-6500元/月', location: '南湾街道', tags: ['五险一金'] },
          ].map((job, i) => (
            <Card key={i} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                <h4 style={{ fontSize: 15, fontWeight: 600, color: theme.text }}>{job.title}</h4>
                <span style={{ fontSize: 15, fontWeight: 700, color: theme.primary, whiteSpace: 'nowrap' }}>
                  {job.salary}
                </span>
              </div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 8 }}>
                {job.tags.map((tag, j) => (
                  <span key={j} style={{
                    padding: '2px 8px', borderRadius: 4, fontSize: 11,
                    background: '#F5F5F5', color: theme.textSecondary,
                  }}>{tag}</span>
                ))}
              </div>
              <span style={{ fontSize: 12, color: theme.textMuted }}>📍 {job.location}</span>
            </Card>
          ))}

          {/* 政策解读 */}
          <h3 style={{ fontSize: 15, fontWeight: 700, color: theme.text, marginBottom: 12, marginTop: 8 }}>
            政策解读
          </h3>
          <Card style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
              <div style={{
                width: 40, height: 40, borderRadius: 10,
                background: '#E3F2FD',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 20, flexShrink: 0,
              }}>📄</div>
              <div>
                <h4 style={{ fontSize: 14, fontWeight: 600, color: theme.text, marginBottom: 4 }}>
                  龙岗区创业补贴政策
                </h4>
                <p style={{ fontSize: 12, color: theme.textMuted, lineHeight: 1.6 }}>
                  最高补贴30万元，涵盖场地租金、社保补贴、创业担保贷款等...
                </p>
              </div>
            </div>
          </Card>

          {/* 快速入口 */}
          <h3 style={{ fontSize: 15, fontWeight: 700, color: theme.text, marginBottom: 12 }}>
            快捷服务
          </h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Card style={{ textAlign: 'center', cursor: 'pointer' }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>💰</div>
              <h4 style={{ fontSize: 14, fontWeight: 600, color: theme.text, marginBottom: 4 }}>
                投资简介
              </h4>
              <p style={{ fontSize: 11, color: theme.textMuted }}>龙岗区招商引资政策</p>
            </Card>
            <Card style={{ textAlign: 'center', cursor: 'pointer' }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>🗺️</div>
              <h4 style={{ fontSize: 14, fontWeight: 600, color: theme.text, marginBottom: 4 }}>
                旅游手册
              </h4>
              <p style={{ fontSize: 11, color: theme.textMuted }}>南湾景点推荐</p>
            </Card>
          </div>
        </div>

        <WxTabBar active="service" />
      </div>
    </ScreenWrapper>
  );
}

// 生活便民服务页 - 增强导航功能
function LifeServicesScreen() {
  const { goBack } = useNavigation();
  const services = [
    { icon: '🏛️', name: 'i龙岗', desc: '龙岗区政务服务' },
    { icon: '🛒', name: '闲鱼', desc: '二手交易平台' },
    { icon: '🍜', name: '外卖', desc: '美团/饿了么' },
    { icon: '🚌', name: '公交查询', desc: '实时公交到站' },
    { icon: '🏥', name: '医院挂号', desc: '在线预约挂号' },
    { icon: '💡', name: '生活缴费', desc: '水电燃气缴费' },
    { icon: '📦', name: '快递查询', desc: '包裹追踪' },
    { icon: '🅿️', name: '停车缴费', desc: '智慧停车' },
    { icon: '🏠', name: '物业报修', desc: '在线报修服务' },
  ];

  return (
    <ScreenWrapper>
      <div style={{ background: theme.bg, height: '100%', paddingBottom: 50, overflow: 'auto' }}>
        <WxNavBar title="生活便民服务" back onBack={goBack} />

        <div style={{ padding: 16 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
            {services.map((s, i) => (
              <Card key={i} style={{
                textAlign: 'center', cursor: 'pointer', padding: '16px 8px',
              }}>
                <div style={{ fontSize: 32, marginBottom: 8 }}>{s.icon}</div>
                <h4 style={{ fontSize: 13, fontWeight: 600, color: theme.text, marginBottom: 2 }}>
                  {s.name}
                </h4>
                <p style={{ fontSize: 10, color: theme.textMuted }}>{s.desc}</p>
              </Card>
            ))}
          </div>

          {/* 提示弹窗示例 */}
          <div style={{
            marginTop: 20,
            padding: '14px 16px',
            background: '#E3F2FD',
            borderRadius: 12,
            borderLeft: `3px solid #2196F3`,
            display: 'flex', alignItems: 'flex-start', gap: 8,
          }}>
            <span style={{ fontSize: 18, flexShrink: 0 }}>ℹ️</span>
            <div>
              <p style={{ fontSize: 13, color: '#1565C0', fontWeight: 600, marginBottom: 4 }}>
                温馨提示
              </p>
              <p style={{ fontSize: 12, color: '#0D47A1', lineHeight: 1.6 }}>
                点击服务图标将跳转至对应小程序或H5页面。部分服务需先完成实名认证。
              </p>
            </div>
          </div>
        </div>

        <WxTabBar active="service" />
      </div>
    </ScreenWrapper>
  );
}

// 不合格党员处置指引页 - 增强导航功能
function DisposalScreen() {
  const { goBack } = useNavigation();
  const [activeStep, setActiveStep] = React.useState(0);

  const situations = [
    '连续6个月不参加党的组织生活',
    '不交纳党费',
    '不做党所分配的工作',
    '无正当理由，连续6个月不参加组织生活',
  ];

  const steps = [
    { title: '提醒谈话', desc: '党支部书记或组织委员对其进行提醒谈话，指出问题，帮助认识错误。', icon: '💬' },
    { title: '限期改正', desc: '经教育仍不改正的，给予限期改正处理，限期一般为6个月至1年。', icon: '⏳' },
    { title: '通报批评', desc: '限期改正期满仍无转变的，在支部大会上通报批评。', icon: '📢' },
    { title: '组织处理', desc: '经支部大会讨论决定，报上级党委批准，给予组织处理。', icon: '📋' },
    { title: '除名', desc: '对不合格党员予以除名处理，并报上级党委备案。', icon: '🚫' },
  ];

  return (
    <ScreenWrapper>
      <div style={{ background: theme.bg, height: '100%', paddingBottom: 50, overflow: 'auto' }}>
        <WxNavBar title="处置指引" back onBack={goBack} />

        <div style={{ padding: 16 }}>
          {/* 情形列表 */}
          <Card style={{ marginBottom: 16 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: theme.text, marginBottom: 12 }}>
              不合格党员情形
            </h3>
            {situations.map((s, i) => (
              <div key={i} style={{
                padding: '10px 0',
                borderBottom: `1px solid ${theme.border}`,
                display: 'flex', alignItems: 'flex-start', gap: 10,
              }}>
                <span style={{
                  width: 20, height: 20, borderRadius: '50%',
                  background: '#FFEBEE', color: theme.primary,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontWeight: 700, flexShrink: 0, marginTop: 2,
                }}>{i + 1}</span>
                <span style={{ fontSize: 13, color: theme.text, lineHeight: 1.5 }}>{s}</span>
              </div>
            ))}
          </Card>

          {/* 流程步骤 */}
          <h3 style={{ fontSize: 15, fontWeight: 700, color: theme.text, marginBottom: 12 }}>
            处置流程
          </h3>

          {steps.map((step, i) => (
            <div
              key={i}
              onClick={() => setActiveStep(i)}
              style={{
                background: theme.white,
                borderRadius: 12,
                marginBottom: 12,
                overflow: 'hidden',
                boxShadow: activeStep === i ? `0 2px 8px rgba(229,57,53,0.15)` : theme.cardShadow,
                border: activeStep === i ? `1px solid ${theme.primaryLight}` : `1px solid transparent`,
              }}
            >
              <div style={{
                padding: '14px 16px',
                display: 'flex', alignItems: 'center', gap: 12,
              }}>
                <span style={{ fontSize: 24 }}>{step.icon}</span>
                <div style={{ flex: 1 }}>
                  <h4 style={{ fontSize: 14, fontWeight: 600, color: theme.text }}>
                    第{i + 1}步：{step.title}
                  </h4>
                </div>
                <span style={{ fontSize: 12, color: theme.textMuted }}>
                  {activeStep === i ? '▾' : '▸'}
                </span>
              </div>

              {activeStep === i && (
                <div style={{
                  padding: '0 16px 14px',
                  borderTop: `1px solid ${theme.border}`,
                  paddingTop: 12,
                }}>
                  <p style={{ fontSize: 13, color: theme.textSecondary, lineHeight: 1.8 }}>
                    {step.desc}
                  </p>
                </div>
              )}
            </div>
          ))}

          {/* 政策依据 */}
          <Card style={{ marginTop: 8 }}>
            <h4 style={{ fontSize: 14, fontWeight: 600, color: theme.text, marginBottom: 8 }}>
              📑 政策依据
            </h4>
            <p style={{ fontSize: 12, color: theme.textSecondary, lineHeight: 1.8 }}>
              《中国共产党党员教育管理工作条例》<br/>
              《关于做好处置不合格党员工作的通知》<br/>
              《中国共产党纪律处分条例》
            </p>
          </Card>
        </div>

        <WxTabBar active="home" />
      </div>
    </ScreenWrapper>
  );
}

// ========== 注册到全局 ==========
Object.assign(window, {
  login: () => <NavigationProvider><LoginScreen /></NavigationProvider>,
  home: () => <NavigationProvider><HomeScreen /></NavigationProvider>,
  profile: () => <NavigationProvider><ProfileScreen /></NavigationProvider>,
  activityHistory: () => <NavigationProvider><ActivityHistoryScreen /></NavigationProvider>,
  checkin: () => <NavigationProvider><CheckinScreen /></NavigationProvider>,
  learning: () => <NavigationProvider><LearningScreen /></NavigationProvider>,
  courseDetail: () => <NavigationProvider><CourseDetailScreen /></NavigationProvider>,
  aiProfile: () => <NavigationProvider><AIProfileScreen /></NavigationProvider>,
  archiveAudit: () => <NavigationProvider><ArchiveAuditScreen /></NavigationProvider>,
  liveActivity: () => <NavigationProvider><LiveActivityScreen /></NavigationProvider>,
  aiQA: () => <NavigationProvider><AIQAScreen /></NavigationProvider>,
  career: () => <NavigationProvider><CareerScreen /></NavigationProvider>,
  lifeServices: () => <NavigationProvider><LifeServicesScreen /></NavigationProvider>,
  disposal: () => <NavigationProvider><DisposalScreen /></NavigationProvider>,
  IosFrame,
  NavigationProvider,
  useNavigation,
});