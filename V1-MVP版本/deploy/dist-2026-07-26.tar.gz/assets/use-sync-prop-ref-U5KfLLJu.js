import{r as c,C as o}from"./index-ZXilWqlQ.js";const n=(s,a)=>{const f=c(s());return o(s,r=>{r!==f.value&&(f.value=r)}),o(f,r=>{r!==s()&&a(r)}),f};export{n as u};
