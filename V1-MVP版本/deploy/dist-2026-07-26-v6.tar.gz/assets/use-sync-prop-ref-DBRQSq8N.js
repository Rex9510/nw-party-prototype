import{r as c,C as o}from"./index-CO36lY3h.js";const n=(s,a)=>{const f=c(s());return o(s,r=>{r!==f.value&&(f.value=r)}),o(f,r=>{r!==s()&&a(r)}),f};export{n as u};
